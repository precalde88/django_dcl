/**
 * @license Highcharts Gantt JS v8.1.2 (2020-06-16)
 * @module highcharts/modules/current-date-indicator
 * @requires highcharts
 *
 * CurrentDateIndicator
 *
 * (c) 2010-2019 Lars A. V. Cabrera
 *
 * License: www.highcharts.com/license
 */
'use strict';
import '../../parts-gantt/CurrentDateIndicator.js';
